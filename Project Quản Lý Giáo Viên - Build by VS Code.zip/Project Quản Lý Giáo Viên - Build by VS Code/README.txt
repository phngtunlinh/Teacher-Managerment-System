Toàn bộ các dữ liệu nằm trong tệp giaovien.txt
Project quản lý danh sách giáo viên với 4 hạng mục thông bao gồm:
1. mã giáo viên
2. tên giáo viên
3. môn học
4. lớp chủ nhiệm
CÁC CHỨC NĂNG CỦA CHƯƠNG TRÌNH:  
1. thêm thông tin và lưu vào file, nếu mã giáo viên nhập vào bị trùng lặp thì không chấp thuận
2. tìm kiếm thông tin đã lưu dựa vào mã giáo viên
3. Hiển thị toàn bộ thông tin đã lưu
4. Chỉnh sửa 1 thông tin đã lưu
5. Xoá thông tin đã lưu thông qua tìm kiếm mã giáo viên
6. Xoá toàn bộ thông tin đã lưu
7. thoát chương trình

PASS XOÁ THÔNG TIN: admin