#include "nhatruong.h"
int main(){
    system("cls");
    menu();
}