#include "giaovien.h"
#ifndef menu_h
#define menu_h
void menu(); //menu
int countLine(string Data_); //dem phan tu trong file
void load_Info(giaovien* &teacher); //lay data trong file
void clearFile(string file); //xoa toan bo data trong file
void exitProgram(); //thoat chuong trinh
#endif