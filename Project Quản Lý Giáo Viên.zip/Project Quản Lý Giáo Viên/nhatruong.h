#include "menu.h"
#ifndef nhatruong_h
#define nhatruong_h
class nhatruong : public giaovien
{
    public:
        void createInfo(giaovien tch);
        void searchInfo();
        void listInfo();
        void modifyInfo();
        void deleteInfo();
        void deleteAll();
};
#endif