#include "giaovien.h"

giaovien :: giaovien()  //constructor no variable
{
    ID = "ID";
    name = "name";
	subject = "subject";
	grade = "grade";
}
giaovien :: giaovien(string ID_, string name_, string subject_, string class_) //constructor with variable
{
	name = name_;
	subject = subject_;
	grade = class_;
	ID = ID_;
}
bool giaovien :: compare(string input)
{
    if (ID == input) 
        return true; 
    else 
        return false;
}
void giaovien :: modify(int a)
{
    string change;
    if (a == 1 )
    { 
        cout <<"Nhap lai Ma giao vien sau chinh sua: "; 
        cin >> change; 
        ID = change;
    }
    if (a == 2 )
    {  
        cout <<"Nhap lai Ten giao vien sau chinh sua: "; 
        cin.ignore(); getline(cin, change); 
        name = change;
    }
    if (a == 3 )
    {  
        cout <<"Nhap lai Mon hoc sau chinh sua: "; 
        cin.ignore(); getline(cin, change); 
        subject = change;
    }
    if (a == 4 )
    { 
        cout <<"Nhap lai Lop chu nhiem sau chinh sua: "; 
        cin.ignore(); getline(cin, change); 
        grade = change;
    }
}
void giaovien :: write(string file){
        ofstream filedata;
        filedata.open (file, ios :: app);
        filedata <<ID << "," << name << "," << subject << "," << grade << endl;
        filedata.close();
}
void giaovien :: output()
{
    cout << ID << "   ||   " << name <<"   ||   " << subject << "   ||   " << grade << endl << endl;
}
